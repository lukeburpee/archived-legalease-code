"""
========
Optimize
========

Optimize is a module to search parameter spaces for optima of an error function.

$Id: __init__.py 366 2008-12-23 21:58:19Z mschmucker $
"""

#__author__="Michael Schmuker"
#__date__ ="$23.12.2008 10:55:36$"
#__version__ = "$Rev$"
#
##__all__ = ['parameter_search', 'optimizers']
#
#from parameter_search import *
#from optimizers import *
