"""
NeuroTools.tisean
==================

A collection of functions to create, manipulate and play with TISEAN functions 
"""

from tisean import *
