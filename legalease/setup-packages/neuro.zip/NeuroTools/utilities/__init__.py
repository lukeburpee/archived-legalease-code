"""
utilities.py

Routines and classes that make life easier.
"""

def imsave(mat,filename):

    raise Exception("This function has been moved to NeuroTools.plotting and is now called save_2D_image(...)!")



def progress_bar(progress):
    
    raise Exception("This function has been moved to NeuroTools.plotting!")



def exportPNGZip(frame_list, filename, frame_duration):

    raise Exception("This function has been moved to NeuroTools.plotting and is now called save_2D_movie(...)!")



def show(url):

    raise Exception("This function has been moved to 'facets.mixedutils' because it contains FACETS specific code!")



def save_image(arr, filename):

    raise Exception("This function has been moved to 'facets.mixedutils' because it contains FACETS specific code!")
