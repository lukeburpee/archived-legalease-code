from __future__ import absolute_import, division, print_function

from .core import istask, get
from .context import set_options

__version__ = '0.5.0'
