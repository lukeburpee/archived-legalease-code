.. _model_selection_examples:

Model Selection
-----------------------

Examples concerning model selection, mostly contained in the
:mod:`sklearn.grid_search` and :mod:`sklearn.cross_validation` modules.
